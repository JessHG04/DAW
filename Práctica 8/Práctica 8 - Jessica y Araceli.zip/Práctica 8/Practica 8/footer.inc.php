
    <footer>
        <p>&copy; Copyright
            <time datetime="2018">2018</time>
             <a href="acerca.php">por Araceli y Jéssica</a>
            <br>
        </p>
    </footer>
</body>
</html>
<?php
    require_once("cerrarConexionBDD.inc.php");
?>