<?php
   // Libera la memoria ocupada por el resultado
   //$resultado->close();
   // Cierra la conexión
   $mysqli->close();
?>